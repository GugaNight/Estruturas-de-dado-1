/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturas;

/**
 *
 * @author gugam
 * @param <T>
 */
public class Pilha<T> {

    private Celula fundo;
    private Celula topo;
    private int Qtd;

    public Pilha() {
    }

    public void Push(T elemento) {

    }

    public boolean isFull() {
        return false;

    }

    public T Top() {
        return null;

    }

    public void Pull(T elemento) {

    }

    public void Pop() {

    }

    public int tamanho() {
        return 0;

    }

    public void limpa() {

    }
}
